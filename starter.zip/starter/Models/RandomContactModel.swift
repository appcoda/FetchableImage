//
//  RandomContactModel.swift
//  FetchableImageDemo
//
//  Created by Gabriel Theodoropoulos.
//  Copyright © 2020 AppCoda. All rights reserved.
//

import SwiftUI

class RandomContactModel: ObservableObject {
    
    @Published var contact = Contact()
    
    private var contacts = [Contact]()
    
    init() {
        loadContacts()
    }
    
    func pickRandomContact() {
        let random = Int.random(in: 0..<10)
        guard random < contacts.count else { return }
        contact = contacts[random]
    }
    
    
    fileprivate func loadContacts() {
        guard let url = Bundle.main.url(forResource: "fakedata_small", withExtension: "json"), let data = try? Data(contentsOf: url) else {
            return
        }
        
        let decoder = JSONDecoder()
        guard let loadedContacts = try? decoder.decode([Contact].self, from: data) else { return }
        
        contacts = loadedContacts
    }
    
}
