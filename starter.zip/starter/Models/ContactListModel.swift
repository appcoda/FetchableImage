//
//  ContactListModel.swift
//  FetchableImageDemo
//
//  Created by Gabriel Theodoropoulos.
//  Copyright © 2020 AppCoda. All rights reserved.
//

import SwiftUI

class ContactListModel: ObservableObject {
    
    @Published var contacts = [Contact]()
    
    @Published var progress: Double = 0.0
    
    @Published var isFetching = false
    
    
    init() {
        loadContacts()
    }
    
    
    private func loadContacts() {
        guard let url = Bundle.main.url(forResource: "fakedata", withExtension: "json"), let data = try? Data(contentsOf: url) else {
            return
        }
        
        let decoder = JSONDecoder()
        guard let loadedContacts = try? decoder.decode([Contact].self, from: data) else { return }
        
        contacts = loadedContacts
    }
    
}
